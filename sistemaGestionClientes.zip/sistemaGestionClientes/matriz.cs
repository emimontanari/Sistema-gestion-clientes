﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sistemaGestionClientes
{
    internal class matriz
    {
        public static Decimal[,] ventas = new Decimal[10, 4];
    }
}
